import"./chunk-ENQRHBTS.js";var t=[{path:"",loadComponent:()=>import("./chunk-TNXSG43J.js").then(o=>o.DashboardComponent),data:{title:$localize`Dashboard`}}];export{t as routes};
