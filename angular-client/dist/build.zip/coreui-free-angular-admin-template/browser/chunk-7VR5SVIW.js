import"./chunk-ENQRHBTS.js";var o=[{path:"",loadComponent:()=>import("./chunk-O65PXIBA.js").then(t=>t.WidgetsComponent),data:{title:"Widgets"}}];export{o as routes};
